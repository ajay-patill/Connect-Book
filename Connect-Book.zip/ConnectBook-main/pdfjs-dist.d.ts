// src/types/pdfjs-dist.d.ts
declare module 'pdfjs-dist/legacy/build/pdf.worker.js' {
    const worker: string;
    export default worker;
  }
  